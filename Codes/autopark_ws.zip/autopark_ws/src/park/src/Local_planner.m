tic
global x y x0 y0  m a b c n s dist L H 

x0 = 14; 
y0 = 20;
m = 0;
n = 0;
dist = 0.05; 
s = 0.005; 
L=0.8;
H=0.5;

Nodes =[];
Node_New =[];

Nodes(:,:,1)= [x0,y0];


%Main


    
plot(x0, y0,'s','MarkerSize',15,'MarkerFaceColor','r','MarkerEdgeColor','r')

XCar = [x0-L/2,x0-L/2,x0+L/2,x0+L/2,x0-L/2];
YCar = [y0-H/2,y0+H/2,y0+H/2,y0-H/2,y0-H/2];
% plot(XCar,YCar,'k');
title('Path Generation')
hold on




x = x0; 
y = y0; 

while (x0 > 0.00)   
% sensor_t(x0,y0,m)   
% calc_abc(x0,y0,m,n) 
% straight(x0,y0,m,dist) 
% sensor_s() 
% calc_n(x0,a,b,c)
% turn(m,n)
% x0 = x;
% y0 = y; 


 x0 = normrnd(x0,s);
 y0 = normrnd(y0,s);
 m = normrnd(m,s); 
 
 a = (n/(2*x0^3)) - 3*m/(x0^4)+ 6*y0/(x0^5);
 b = m/(x0^3) - 3*y0/(x0^4);
 c = y0/(x0^3);  
 
 
 
 x = x0 - dist/(sqrt(1+m^2));
 y = y0 - (m*dist)/(sqrt(1+m^2)); 
 
 Node_New = [x,y];
 Nodes = cat(3,Nodes,Node_New);
 
 plot(x,y,'o','MarkerEdgeColor','g','MarkerSize',3,'MarkerFaceColor','b')
 drawnow
 
 
%  elseif i==1
%  plot(x,y,'o','MarkerEdgeColor','b','MarkerSize',3,'MarkerFaceColor','r')
%  hold on
%  elseif i==2
%  plot(x,y,'o','MarkerEdgeColor','b','MarkerSize',3,'MarkerFaceColor','g') 
%  hold on
%  elseif i==3
%  plot(x,y,'o','MarkerEdgeColor','b','MarkerSize',3,'MarkerFaceColor','y') 
%  hold on
 
 
%  XCar_moving = [x-L/2,x-L/2,x+L/2,x+L/2,x-L/2];
%  YCar_moving = [y-H/2,y+H/2,y+H/2,y-H/2,y-H/2];
%  plot(XCar_moving,YCar_moving);

 
 x = normrnd(x,s);
 y = normrnd(y,s);
 m = normrnd(m,s); 
 
 n = 6*a*x*(x-x0)^2 + 12*a*(x^2)*(x-x0)+6*b*x*(x- x0) + 2*a*(x^3) + 6*b*(x^2) + 6*(c*x);
 
 m = m + n*(x - x0); 
 
 x0=x;
 y0=y;
end

if x0<0
plot(x, y,'s','MarkerSize',15,'MarkerFaceColor','g','MarkerEdgeColor','g')

XCar = [x0-L/2,x0-L/2,x0+L/2,x0+L/2,x0-L/2];
YCar = [y0-H/2,y0+H/2,y0+H/2,y0-H/2,y0-H/2];
% plot(XCar,YCar,'k');

end

toc


