%Generates Tentative Map for given rrl.ttt file in 2D

% Res=1;
%Plotting Scene
% Table1
XSq = [[-600,-600,-650,-650,-600]+750]*Res;
YSq = [[-500,-350,-350,-500,-500]+500]*Res;
drawnow 
plot(XSq,YSq);
hold on
fill(XSq,YSq,'b');

%Table2
XSq1 = [[-400,-400,-450,-450,-400]+750]*Res;
YSq1 = [[-500,-350,-350,-500,-500]+500]*Res ;
drawnow
plot(XSq1,YSq1);
fill(XSq1,YSq1,'b');

%Table3
XSq2 = [[-200,-200,-250,-250,-200]+750]*Res;
YSq2 = [[-500,-350,-350,-500,-500]+500]*Res ;
drawnow
plot(XSq2,YSq2);
fill(XSq2,YSq2,'b');

%Table4
XSq3 = [[0 0 50 50 0]+750]*Res;
YSq3 = [[-500,-350,-350,-500,-500]+500]*Res ;
drawnow
plot(XSq3,YSq3);
fill(XSq3,YSq3,'b');

%Conference Table
XSq4 = [[-600,-600,-650,-650,-600]+750]*Res;
YSq4 = [[-500,-350,-350,-500,-500]+500+500]*Res;
drawnow
plot(XSq4,YSq4);
fill(XSq4,YSq4,'b');

%Conference Table 1
XSq5 = [[-400,-400,-450,-450,-400]+750]*Res;
YSq5 = [[-500,-350,-350,-500,-500]+500+500]*Res ;
drawnow
plot(XSq5,YSq5);
fill(XSq5,YSq5,'b');

%Dining Table
XSq6 = [[-200,-200,-250,-250,-200]+750]*Res;
YSq6 = [[-500,-350,-350,-500,-500]+500+500]*Res ;
drawnow
plot(XSq6,YSq6);
fill(XSq6,YSq6,'b');

%Dining Table
XSq7 = [[0 0 50 50 0]+750]*Res;
YSq7 = [[-500,-350,-350,-500,-500]+500+500]*Res ;
drawnow
plot(XSq7,YSq7);
fill(XSq7,YSq7,'b');

%Dining Table
XSq7 = [[1000 1000 1200 1200 1000]+750]*Res;
YSq7 = [[-300,0 0,-300,-0]+500+500]*Res ;
drawnow
plot(XSq7,YSq7);
fill(XSq7,YSq7,'b');


%Scene Boundary
xp3 = [[-750,-750 750,750,-750]+750]*Res;
yp3 = [[-500,500,500,-500,-500]+500]*Res;
drawnow
plot(xp3,yp3);
alpha(0.3);
