1.)2D_RRL Map---Map or rrl_ideal.ttt in 2D

2.)Obstacle Coordinates Rough Work shown in above-named pdf.

3.)PlanningProject3Part1--------> A* in Planning project 2 Mapspace

4.)Project3Part2in2D------------->A* in 2D Space of rrl_ideal.ttt
   Comments: Taking very long time to process the path, in centimeter resolution, trying meter resolution
   Run Directly after specifying Start_Point and Goal_Point in the Program 
   Functions are built in the same script.

5.)rempApi,remoteApi.dll,remoteApiProto,Vrep_matlab_Readme---> Given by Vrep to enable remoteApi


 -------------------------------------------------- SCRIPT INCOMPLETE---------------------------------------------------
6.)TurtleBot.m----->Client-Side Script for moving turtlebot according to path recieved from Project3Part2in2D.m
   Comments: Established Connection to Vrep
             Initialized the Velocity Parameters, wrote functions for kinematics
             Got Position/Orientation for Initializing
             Aim: To get the turtlebot to reach the given target point within a specified tolerance

7.) motion_params.txt -----> Text File Containing Veolcity Paramaters are given Instances of time (Not Built)
 
8.) rrl_ideal.ttt---------> Given Vrep Compatible Scene

