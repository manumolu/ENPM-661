%Loading Path Details found from Project3Part2in2D
load('TurtleBotPath.mat','path');
%Initializing Matlab RemoteApi
vrep=remApi('remoteApi');
vrep.simxFinish(-1);
clientID=vrep.simxStart('127.0.0.1',19999,true,true,5000,5);
%Tolerance after which robot is considered to have reached Target Position
Tolerance=0.2;
%InitializingMotion Parameters for Text File
linear.x = 0;
linear.y = 0;
linear.z = 0;
angular.x = 0;
angular.y = 0;
angular.z = 0;
timeStamp = 0;
fileID = fopen('motion_params.txt','w');
fprintf(fileID,'%10s %15s %20s %25s %30s %35s %40s\r\n','time','linear.x','linear.y','linear.z','angular.,x','angular.y','angular.z');

if (clientID>-1)
    disp('RemoteApi Connection to Server Established');
    
    % Object Handles from Vrep
    [~,Robot]=vrep.simxGetObjectHandle(clientID,'Turtlebot2',vrep.simx_opmode_blocking) ;  
    [~,left_Motor]=vrep.simxGetObjectHandle(clientID,'wheel_left_joint',vrep.simx_opmode_blocking);
    [~,right_Motor]=vrep.simxGetObjectHandle(clientID,'wheel_right_joint',vrep.simx_opmode_blocking);
    
    % Get the position and Angle of the Robot from Vrep
    [~,position]=vrep.simxGetObjectPosition(clientID,Robot,-1,vrep.simx_opmode_blocking);
    [returnCode,angle]=vrep.simxGetObjectOrientation(clientID,Robot,-1,vrep.simx_opmode_blocking);

    %Get Path Details from Project3Part2in2D
    path = flipud(path);
    k = length(path);
   
    Pathx = path(:,1,:)-75;
    Pathy = path(:,2,:)-50;
   
    % Initialize the Current and Target Position
    current_pos =[round(position(1,1),1),round(position(1,2),1)];
    target_pos = [Pathx(k),Pathy(k)];
    
    %Robot Parameters
    radius = 0.038;
    dist_wheels=0.3175;
    i = 2;
    tic
    while norm(current_pos - target_pos) > Tolerance
        % Get the coordinates of the next point
        next_pos = [Pathx(i),Pathy(i)];
        i = i+1 ;

        % Slope  = (y2-y1)/(x2-x1)
        slope=GetSlope(current_pos,next_pos);
path(
        % Orientation of Robot (Vrep)
        [~,angle]=vrep.simxGetObjectOrientation(clientID,Robot,-1,vrep.simx_opmode_blocking);
        
        % Calculate the velocity of both weheels
        time = 0.5;
        vel_right = ((slope - angle(3))*dist_wheels)/(2*radius*time);
        vel_left = -vel_right;
        while abs(vel_right) > 2 
            time = time + 0.5 ;
            vel_right = ((slope - angle(3))*dist_wheels)/(2*radius*time);
            vel_left = -vel_right;
        end
        
        timeStamp = toc;
        [x_dot,y_dot ,theta_dot] = extract_velocity(vel_right, vel_left,slope);
        line = [timeStamp x_dot y_dot linear.z theta_dot angular.y angular.z];
        fprintf(fileID,'%10f %15f %20f %25f %30f %35f %40f\r\n', line);

        while (abs((slope) - angle(3))) > 0.04
            [returnCode]=vrep.simxSetJointTargetVelocity(clientID,left_Motor,vel_left,vrep.simx_opmode_blocking);
            [returnCode]=vrep.simxSetJointTargetVelocity(clientID,right_Motor,vel_right,vrep.simx_opmode_blocking);
            [~,angle]=vrep.simxGetObjectOrientation(clientID,Robot,-1,vrep.simx_opmode_blocking);
        end
        
        [returnCode]=vrep.simxSetJointTargetVelocity(clientID,left_Motor,0,vrep.simx_opmode_blocking);
        [returnCode]=vrep.simxSetJointTargetVelocity(clientID,right_Motor,0,vrep.simx_opmode_blocking);

        time = 0.05;
        [~,position]=vrep.simxGetObjectPosition(clientID,Robot,-1,vrep.simx_opmode_blocking);
        current_pos = [position(1),position(2)]; 

        vel_right = (norm(next_pos -current_pos))/time;
        vel_left=vel_right;
        
        timeStamp = toc;
        [x_dot,y_dot,theta_dot] = extract_velocity(vel_right, vel_left, slope);
        line = [timeStamp x_dot y_dot linear.z theta_dot angular.y angular.z];
        fprintf(fileID,'%10f %15f %20f %25f %30f %35f %40f\r\n', line);
        
        while abs(vel_right) > 8 
            time = time + 0.01 ;
            vel_right = (norm(next_pos -current_pos))/time;
            vel_left = vel_right;
        end
        
        [~,position]=vrep.simxGetObjectPosition(clientID,Robot,-1,vrep.simx_opmode_blocking);
        current_pos = [position(1),position(2)];    

        while ((norm(next_pos -current_pos)) > 0.09)
            norm(next_pos -current_pos)
            [returnCode]=vrep.simxSetJointTargetVelocity(clientID,left_Motor,vel_left,vrep.simx_opmode_blocking);
            [returnCode]=vrep.simxSetJointTargetVelocity(clientID,right_Motor,vel_right,vrep.simx_opmode_blocking);
            [~,position]=vrep.simxGetObjectPosition(clientID,Robot,-1,vrep.simx_opmode_blocking);
            current_pos = [position(1),position(2)];
        end

        [returnCode]=vrep.simxSetJointTargetVelocity(clientID,left_Motor,0,vrep.simx_opmode_blocking);
        [returnCode]=vrep.simxSetJointTargetVelocity(clientID,right_Motor,0,vrep.simx_opmode_blocking);

        % Position Update
        [returnCode,position]=vrep.simxGetObjectPosition(clientID,Robot,-1,vrep.simx_opmode_blocking);
        current_pos = [position(1),position(2)];
    end
    vrep.simxFinish(-1);
end 

vrep.delete();

%Function for getting Velocity Parameters for Robot and Getting Slope Given
%Current and Next Position
function [x_dot,y_dot,theta_dot] = extract_velocity(vel_right,vel_left, angle)
    %Parameters given in TurtleBot Spec Sheet 
    r = 0.038;      
    L = 0.3175;
    x_dot = (r/2)*(vel_right+vel_left)*cos(angle);
    y_dot = (r/2)*(vel_right+vel_left)*sin(angle);
    theta_dot = (r/L)*(vel_right-vel_left);
end    
    
function [slope] = GetSlope (current_pos,next_pos)
%Slope = Tan^-1(ydiff/xdiff)
slope = atan2(round((next_pos(2)-current_pos(2)),1),round((next_pos(1)-current_pos(1)),1));
if slope > pi-0.05 || slope < -pi +0.05
slope=0;
else
slope = slope + pi;
end
end